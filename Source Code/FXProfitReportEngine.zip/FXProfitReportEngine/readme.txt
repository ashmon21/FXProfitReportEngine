****
PROJECT: FX PROFIT REPORT ENGINE
****

Please run the project in any IDE via FXProfitReportApplication.launch file in /resources/ide. 

The project will take the sample dataset given as input, which are already included under src/main/resources/data directory. 
If you want to use other dataset, please edit the relevant file paths on src/main/config/application.properties.