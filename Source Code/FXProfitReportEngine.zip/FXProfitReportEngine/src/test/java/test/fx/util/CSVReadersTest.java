package test.fx.util;

import static org.junit.Assert.*;

import java.time.LocalTime;
import java.util.List;

import org.junit.Test;

import com.fx.constants.ClientType;
import com.fx.constants.Currency;
import com.fx.model.MarketRate;
import com.fx.model.Transaction;
import com.fx.util.RatesReader;
import com.fx.util.TransactionsReader;

public class CSVReadersTest {

	TransactionsReader tReader = new TransactionsReader();

	RatesReader rReader = new RatesReader();

	@Test
	public void testReadTransactions() {
		List<Transaction> transactions = tReader
				.getTransactionsFromCSV("src/test/resources/data/test_transactions.csv");

		assertEquals(1, transactions.size());
		Transaction t = transactions.get(0);
		assertEquals(Currency.CNY, t.getBasedCurrency());
		assertEquals(Currency.SGD, t.getWantedCurrency());
		assertEquals(new Double(40000), t.getBasedCurrencyAmount());
		assertEquals(ClientType.INDIVIDUAL, t.getClientType());
		assertEquals(LocalTime.of(8, 32), t.getTransactionTime());
	}

	@Test
	public void testReadRates() {

		List<MarketRate> rates = rReader.getMarketRatesFromCSV("src/test/resources/data/test_rates.csv");

		assertEquals(3, rates.size());
		MarketRate r = rates.get(0);
		assertEquals(Currency.CNY, r.getBasedCurrency());
		assertEquals(Currency.SGD, r.getWantedCurrency());
		assertEquals(new Double(0.2012), r.getRate());
		assertEquals(LocalTime.of(9, 0), r.getExpiryTime());
	}

}
