package test.fx.report;

import static org.junit.Assert.*;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.fx.constants.ClientType;
import com.fx.constants.Currency;
import com.fx.model.MarketRate;
import com.fx.model.Transaction;
import com.fx.report.ReportGenerator;

public class ReportGeneratorTest {

	private ReportGenerator generator = new ReportGenerator();
	
	@Test
	public void testFindMarketRate() {
		Transaction t1 = new Transaction(Currency.CNY, Currency.SGD, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(8, 32));
		Transaction t2 = new Transaction(Currency.CNY, Currency.SGD, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(9, 1));
		Transaction t3 = new Transaction(Currency.CNY, Currency.USD, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(7, 1));
		Transaction t4 = new Transaction(Currency.CNY, Currency.SGD, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(9, 0));
		Transaction t5 = new Transaction(Currency.CNY, Currency.SGD, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(11, 22));
		Transaction t6 = new Transaction(Currency.CNY, Currency.SGD, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(11, 45));
		Transaction t7 = new Transaction(Currency.CNY, Currency.EUR, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(12, 45));
		Transaction t8 = new Transaction(Currency.CNY, Currency.SGD, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(12, 45));

		setMarketRates();

		assertEquals(0, Double.compare(generator.findMarketRate(t1), 0.2012));
		assertEquals(0, Double.compare(generator.findMarketRate(t2), 0.2013));
		assertEquals(0, Double.compare(generator.findMarketRate(t3), 0.161));
		assertEquals(0, Double.compare(generator.findMarketRate(t4), 0.2012));
		assertEquals(0, Double.compare(generator.findMarketRate(t5), 0.2014));
		assertEquals(0, Double.compare(generator.findMarketRate(t6), 0.2015));
		assertEquals(0, Double.compare(generator.findMarketRate(t7), 0.0));
		assertEquals(0, Double.compare(generator.findMarketRate(t8), 0.0));
	}
	
	private void setMarketRates() {
		List<MarketRate> rates = new ArrayList<>();
		rates.add(new MarketRate(Currency.CNY, Currency.SGD, 0.2012, LocalTime.of(9, 0)));
		rates.add(new MarketRate(Currency.CNY, Currency.USD, 0.161, LocalTime.of(9, 0)));
		rates.add(new MarketRate(Currency.CNY, Currency.SGD, 0.2013, LocalTime.of(11, 0)));
		rates.add(new MarketRate(Currency.CNY, Currency.SGD, 0.2014, LocalTime.of(11, 30)));
		rates.add(new MarketRate(Currency.CNY, Currency.SGD, 0.2015, LocalTime.of(12, 0)));

		generator.setMarketRates(rates);
	}

	@Test
	public void testFindMarkUpRate() {
		setMarketRates();
		double usd_rate = 0.161;

		Transaction t1 = new Transaction(Currency.CNY, Currency.SGD, 5000.0 / usd_rate, ClientType.INDIVIDUAL,
				LocalTime.of(8, 32));
		Transaction t2 = new Transaction(Currency.CNY, Currency.SGD, 8000.0 / usd_rate, ClientType.INDIVIDUAL,
				LocalTime.of(8, 32));
		Transaction t3 = new Transaction(Currency.CNY, Currency.SGD, 21000.0 / usd_rate, ClientType.INDIVIDUAL,
				LocalTime.of(8, 32));
		Transaction t4 = new Transaction(Currency.CNY, Currency.SGD, 50000.0 / usd_rate, ClientType.INDIVIDUAL,
				LocalTime.of(8, 32));

		assertEquals(40, generator.findMarkUpRate(t1));
		assertEquals(40, generator.findMarkUpRate(t2));
		assertEquals(30, generator.findMarkUpRate(t3));
		assertEquals(25, generator.findMarkUpRate(t4));

		Transaction t5 = new Transaction(Currency.CNY, Currency.SGD, 3500000.0 / usd_rate, ClientType.CORPORATE,
				LocalTime.of(8, 32));
		Transaction t6 = new Transaction(Currency.CNY, Currency.SGD, 1000000.0 / usd_rate, ClientType.CORPORATE,
				LocalTime.of(8, 32));
		Transaction t7 = new Transaction(Currency.CNY, Currency.SGD, 2500000.0 / usd_rate, ClientType.CORPORATE,
				LocalTime.of(8, 32));

		assertEquals(5, generator.findMarkUpRate(t5));
		assertEquals(15, generator.findMarkUpRate(t6));
		assertEquals(10, generator.findMarkUpRate(t7));
	}
	
	@Test
	public void testGenerateReportRow(){
		setMarketRates();
		
		Transaction t1 = new Transaction(Currency.CNY, Currency.SGD, 40000.0, ClientType.INDIVIDUAL,
				LocalTime.of(8, 32));
		
		String expected_row = "CNY,SGD,40000,0.2012,0.2004,32,32";
		assertEquals(expected_row, generator.getOutputRow(t1));
	}

}
