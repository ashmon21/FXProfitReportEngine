package test.fx.constants;

import static org.junit.Assert.*;

import org.junit.Test;
import com.fx.constants.Currency;

public class ConstantsTest {

	@Test
	public void testGetCurrencyValue() {
		String nullCurrency = null;
		String emptyCurrency = "";
		String wrongCurrency = "SDG";
		String correctCurrency = "SGD";

		assertNull(Currency.getValueOf(nullCurrency));
		assertNull(Currency.getValueOf(emptyCurrency));
		assertNull(Currency.getValueOf(wrongCurrency));
		assertEquals(Currency.SGD, Currency.getValueOf(correctCurrency));
	}
}
