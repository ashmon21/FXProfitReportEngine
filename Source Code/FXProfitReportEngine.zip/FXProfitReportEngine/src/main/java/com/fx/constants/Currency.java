package com.fx.constants;

public enum Currency {
	CNY, SGD, AUD, USD, EUR;

	public static Currency getValueOf(String str) {
		for (Currency c : Currency.values()) {
			if (c.toString().equalsIgnoreCase(str)) {
				return c;
			}
		}
		return null;
	}
}
