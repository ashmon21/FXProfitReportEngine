package com.fx.application;

import com.fx.report.ReportGenerator;

public class Application {
	public static void main(String[] args) {
		ReportGenerator g = new ReportGenerator();
		g.init();
	}
}
