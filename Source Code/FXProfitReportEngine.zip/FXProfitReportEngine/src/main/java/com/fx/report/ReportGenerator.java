package com.fx.report;

import java.text.DecimalFormat;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.List;
import java.util.NavigableMap;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import com.fx.constants.ClientType;
import com.fx.constants.Currency;
import com.fx.constants.MarkUp;
import com.fx.model.MarketRate;
import com.fx.model.Transaction;
import com.fx.util.CSVUtil;
import com.fx.util.PropertiesUtil;
import com.fx.util.RatesReader;
import com.fx.util.TransactionsReader;

public class ReportGenerator {

	private List<MarketRate> marketRates;

	private Properties properties;

	private TransactionsReader transactions_reader;

	private RatesReader rates_reader;

	private final Logger logger = Logger.getLogger(ReportGenerator.class.getName());

	private final static String TRANSACTION_FILE = "transaction_file";

	private final static String MARKET_RATE_FILE = "market_rate_file";

	private static final String OUTPUT_FILE = "output_file";

	private static final String OUTPUT_FILE_HEADERS = "output_file_headers";

	private final DecimalFormat two_df = new DecimalFormat("#.##");

	private final DecimalFormat four_df = new DecimalFormat("#.####");

	public void setMarketRates(List<MarketRate> marketRates) {
		this.marketRates = marketRates;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public void setTransactions_reader(TransactionsReader transactions_reader) {
		this.transactions_reader = transactions_reader;
	}

	public void setRates_reader(RatesReader rates_reader) {
		this.rates_reader = rates_reader;
	}

	public void init() {
		Properties props = PropertiesUtil.loadPropertiesFromFile();

		if (props != null) {
			setProperties(props);
			setTransactions_reader(new TransactionsReader());
			setRates_reader(new RatesReader());
			setMarketRates(rates_reader.getMarketRatesFromCSV(properties.getProperty(MARKET_RATE_FILE)));

			generateReport();
		}

	}

	public void generateReport() {

		List<Transaction> transactions = transactions_reader
				.getTransactionsFromCSV(properties.getProperty(TRANSACTION_FILE));

		List<String> rows = new LinkedList<>();
		if (properties.containsKey(OUTPUT_FILE_HEADERS)) {
			rows.add(properties.getProperty(OUTPUT_FILE_HEADERS));
		}

		transactions.forEach(t -> {
			rows.add(getOutputRow(t));
		});

		try {
			String output_file = CSVUtil.writeToFile(properties.getProperty(OUTPUT_FILE), rows);
			logger.log(Level.INFO, "The FX_PROFIT report has been generated at " + output_file);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error writing results to output file. " + e.getMessage());
			e.printStackTrace();
		}
	}

	public String getOutputRow(Transaction t) {

		double rate = findMarketRate(t);
		double mark_up = findMarkUpRate(t);
		
		double final_rate = Math.round((rate * (1 - (mark_up / 10000.0))) * 10000.0) / 10000.0;
		double profit = (rate - final_rate) * t.getBasedCurrencyAmount();

		double profit_sgd = t.getWantedCurrency().equals(Currency.SGD) ? profit
				: convertToCurrency(t.getWantedCurrency(), Currency.SGD, t.getTransactionTime(), profit);

		String[] array = new String[] { t.getBasedCurrency().toString(), t.getWantedCurrency().toString(),
				two_df.format(t.getBasedCurrencyAmount()), four_df.format(rate), four_df.format(final_rate),
				two_df.format(profit), two_df.format(profit_sgd) };

		return String.join(CSVUtil.CSV_DELIMITER, array);
	}

	public double findMarketRate(Transaction t) {
		return findMarketRate(t.getBasedCurrency(), t.getWantedCurrency(), t.getTransactionTime());
	}

	public int findMarkUpRate(Transaction t) {

		double amountInUSD = t.getBasedCurrency().equals(Currency.USD) ? t.getBasedCurrencyAmount()
				: convertToCurrency(t.getBasedCurrency(), Currency.USD, t.getTransactionTime(),
						t.getBasedCurrencyAmount());
		
		NavigableMap<Double, Integer> markup_map = t.getClientType().equals(ClientType.INDIVIDUAL)
				? MarkUp.INDIVIDUAL_MARKUP_MAP : MarkUp.CORPORATE_MARKUP_MAP;

		// For corporate clients, convert the amount from 10^6 form
		amountInUSD = t.getClientType().equals(ClientType.CORPORATE) ? amountInUSD / 1000000 : amountInUSD;

		return markup_map.lowerEntry(amountInUSD).getValue();
	}

	private Double convertToCurrency(Currency from, Currency to, LocalTime transaction_time, double amount) {

		return findMarketRate(from, to, transaction_time) * amount;
	}

	private double findMarketRate(Currency from, Currency to, LocalTime transaction_time) {

		List<MarketRate> ratesForTransaction = marketRates.stream()
				.filter(r -> r.getBasedCurrency().equals(from) && r.getWantedCurrency().equals(to))
				.collect(Collectors.toList());

		LocalTime min_time = LocalTime.MAX;

		double rate = 0.0;

		for (MarketRate r : ratesForTransaction) {
			LocalTime rate_expiry = r.getExpiryTime();

			int diff = rate_expiry.compareTo(transaction_time);

			if (diff == 0) {
				min_time = rate_expiry;
				rate = r.getRate();
				continue;
			}

			if (diff == 1 && rate_expiry.compareTo(min_time) == -1) {
				min_time = rate_expiry;
				rate = r.getRate();
			}
		}

		if (rate == 0.00) {
			logger.log(Level.SEVERE,
					String.format("No market rate available for %s to %s transactions at %s. Using 0 as market rate",
							from, to, transaction_time));
		}

		return rate;
	}
}
