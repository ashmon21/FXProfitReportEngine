package com.fx.util;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class CSVReader {

	protected LocalTime getTimeFromString(String str) throws Exception {
		return LocalTime.parse(str, DateTimeFormatter.ofPattern("H:m"));
	}
}
