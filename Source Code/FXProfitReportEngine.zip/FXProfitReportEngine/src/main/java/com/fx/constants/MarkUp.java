package com.fx.constants;

import java.util.Collections;
import java.util.NavigableMap;
import java.util.TreeMap;

public class MarkUp {

	public static final NavigableMap<Double, Integer> INDIVIDUAL_MARKUP_MAP;

	public static final NavigableMap<Double, Integer> CORPORATE_MARKUP_MAP;

	static {

		NavigableMap<Double, Integer> i_map = new TreeMap<>();
		i_map.put(0.00, 40);
		i_map.put(8000.00, 35);
		i_map.put(20000.00, 30);
		i_map.put(35000.00, 25);

		NavigableMap<Double, Integer> c_map = new TreeMap<>();
		c_map.put(0.00, 15);
		c_map.put(1.00, 10);
		c_map.put(3.00, 5);

		INDIVIDUAL_MARKUP_MAP = Collections.unmodifiableNavigableMap(i_map);
		CORPORATE_MARKUP_MAP = Collections.unmodifiableNavigableMap(c_map);
	}

}
