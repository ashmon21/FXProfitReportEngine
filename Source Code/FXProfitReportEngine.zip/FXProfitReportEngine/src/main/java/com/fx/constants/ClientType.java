package com.fx.constants;

public enum ClientType {
	INDIVIDUAL, CORPORATE;

	public static ClientType getValueOf(String str) {
		for (ClientType c : ClientType.values()) {
			if (c.toString().equalsIgnoreCase(str)) {
				return c;
			}
		}
		return null;
	}
}
