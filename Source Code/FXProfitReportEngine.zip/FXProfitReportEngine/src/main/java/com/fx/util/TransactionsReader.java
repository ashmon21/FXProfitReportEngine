package com.fx.util;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.fx.constants.ClientType;
import com.fx.constants.Currency;
import com.fx.model.Transaction;

public class TransactionsReader extends CSVReader {
	
	private Logger logger = Logger.getLogger(TransactionsReader.class.getName());
	
	public List<Transaction> getTransactionsFromCSV(String fileName) {

		List<Transaction> transactions = new ArrayList<>();

		try {
			List<String> t_rows = CSVUtil.getRowsFromCSV(fileName);
			t_rows.forEach(row -> {
				Transaction t = getTransactionFromRow(row);
				if (t != null) {
					transactions.add(t);
				}
			});
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error getting transactions from CSV File. " + e.getMessage());
			e.printStackTrace();
		}

		return transactions;

	}
	
	private Transaction getTransactionFromRow(String line) {

		String[] fields = line.split(CSVUtil.CSV_DELIMITER);
		
		Currency bc = Currency.getValueOf(fields[0]);
		Currency wc = Currency.getValueOf(fields[1]);

		if (bc == null || wc == null) {
			logger.log(Level.WARNING, String.format("Found invalid currency at line: %s. Skipping.", line));
			return null;
		}

		Double baseAmount = 0.00;

		try {
			baseAmount = Double.parseDouble(fields[2]);
		} catch (NumberFormatException e) {
			logger.log(Level.WARNING, String.format("Found invalid number for amount at line: %s. Skipping.", line));
			return null;
		}

		ClientType clientType = ClientType.getValueOf(fields[3]);

		if (clientType == null) {
			logger.log(Level.WARNING, String.format("Found invalid client type at line: %s. Skipping.", line));
			return null;
		}

		LocalTime time = null;

		try {
			time = getTimeFromString(fields[4]);
		} catch (Exception e) {
			logger.log(Level.WARNING, String.format("Found invalid timestamp at line: %s. Skipping.", line));
			return null;
		}

		return new Transaction(bc, wc, baseAmount, clientType, time);
	}
}
