package com.fx.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PropertiesUtil {

	private static final Logger logger = Logger.getLogger(PropertiesUtil.class.getName());

	private static final String CONFIG_FILE = "config_file";

	public static Properties loadPropertiesFromFile() {

		String file = System.getProperty(CONFIG_FILE);

		if (file == null || file.isEmpty()) {
			logger.log(Level.SEVERE, "Please specify " + CONFIG_FILE + " in your System properties.");
			return null;
		}

		Properties props = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream(file);
			props.load(input);
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Fail to load properties file: " + file);
			e.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return props;
	}
}
