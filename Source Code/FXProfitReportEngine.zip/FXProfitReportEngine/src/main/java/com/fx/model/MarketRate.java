package com.fx.model;

import java.time.LocalTime;

import com.fx.constants.Currency;

public class MarketRate {
	private Currency basedCurrency;
	private Currency wantedCurrency;
	private Double rate;
	private LocalTime expiryTime;

	public MarketRate(Currency basedCurrency, Currency wantedCurrency, Double rate, LocalTime expiryTime) {
		super();
		this.basedCurrency = basedCurrency;
		this.wantedCurrency = wantedCurrency;
		this.rate = rate;
		this.expiryTime = expiryTime;
	}

	public Currency getBasedCurrency() {
		return basedCurrency;
	}

	public Currency getWantedCurrency() {
		return wantedCurrency;
	}

	public Double getRate() {
		return rate;
	}

	public LocalTime getExpiryTime() {
		return expiryTime;
	}

}
