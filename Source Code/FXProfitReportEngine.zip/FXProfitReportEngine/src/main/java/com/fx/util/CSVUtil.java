package com.fx.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVUtil {

	private static final String NEW_LINE_SEPARATOR = "\n";
	
	public static final String CSV_DELIMITER = ",";

	public static List<String> getRowsFromCSV(String file) throws Exception {

		if (file == null || file.isEmpty()) {
			throw new Exception(String.format("Please specify the correct input file properties."));
		}

		List<String> rows = new ArrayList<>();

		BufferedReader br = null;

		try {
			br = new BufferedReader(new FileReader(file));
			String row = null;

			while ((row = br.readLine()) != null) {
				rows.add(row);
			}
		} catch (FileNotFoundException e) {
			throw new Exception(
					String.format("Transaction file %s cannot be found. Please check that your file exists.", file));
		} catch (IOException e) {
			throw new Exception("IOException occured while reading the transaction file. " + e.getMessage());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					throw new Exception("IOException occured while reading the transaction file. " + e.getMessage());
				}
			}
		}

		return rows;
	}

	public static String writeToFile(String file, List<String> rows) throws Exception {
		if (file == null || file.isEmpty()) {
			throw new Exception(String.format("Please specify the correct output file property."));
		}

		FileWriter writer = new FileWriter(file);
		for (String row : rows) {
			writer.write(row);
			writer.write(NEW_LINE_SEPARATOR);
		}

		writer.flush();
		writer.close();

		return new File(file).getAbsolutePath();
	}

}
