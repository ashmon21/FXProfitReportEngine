package com.fx.model;

import java.time.LocalTime;

import com.fx.constants.ClientType;
import com.fx.constants.Currency;

public class Transaction {

	private Currency basedCurrency;
	private Currency wantedCurrency;
	private Double basedCurrencyAmount;
	private ClientType clientType;
	private LocalTime transactionTime;

	public Transaction(Currency basedCurrency, Currency wantedCurrency, Double basedCurrencyAmount,
			ClientType clientType, LocalTime transactionTime) {
		super();
		this.basedCurrency = basedCurrency;
		this.wantedCurrency = wantedCurrency;
		this.basedCurrencyAmount = basedCurrencyAmount;
		this.clientType = clientType;
		this.transactionTime = transactionTime;
	}

	public Currency getBasedCurrency() {
		return basedCurrency;
	}

	public Currency getWantedCurrency() {
		return wantedCurrency;
	}

	public Double getBasedCurrencyAmount() {
		return basedCurrencyAmount;
	}

	public ClientType getClientType() {
		return clientType;
	}

	public LocalTime getTransactionTime() {
		return transactionTime;
	}

}
