package com.fx.util;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.fx.constants.Currency;
import com.fx.model.MarketRate;

public class RatesReader extends CSVReader {

	private Logger logger = Logger.getLogger(RatesReader.class.getName());

	public List<MarketRate> getMarketRatesFromCSV(String fileName) {

		List<MarketRate> marketRates = new ArrayList<>();

		try {
			List<String> r_rows = CSVUtil.getRowsFromCSV(fileName);
			r_rows.forEach(row -> {
				MarketRate r = getMarketRateFromRow(row);
				if (r != null) {
					marketRates.add(r);
				}
			});
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error getting market rates from CSV File. " + e.getMessage());
			e.printStackTrace();
		}

		return marketRates;

	}

	private MarketRate getMarketRateFromRow(String line) {
		String[] fields = line.split(CSVUtil.CSV_DELIMITER);

		Currency bc = Currency.getValueOf(fields[0]);
		Currency wc = Currency.getValueOf(fields[1]);

		if (bc == null || wc == null) {
			logger.log(Level.WARNING, String.format("Found invalid currency at line: %s. Skipping.", line));
			return null;
		}

		Double rate = 0.00;

		try {
			rate = Double.parseDouble(fields[2]);
		} catch (NumberFormatException e) {
			logger.log(Level.WARNING, String.format("Found invalid number for amount at line: %s. Skipping.", line));
			return null;
		}

		LocalTime time = null;

		try {
			time = getTimeFromString(fields[3]);
		} catch (Exception e) {
			logger.log(Level.WARNING, String.format("Found invalid timestamp at line: %s. Skipping.", line));
			return null;
		}

		return new MarketRate(bc, wc, rate, time);
	}

}
